import React from 'react'

const admin = () => {
  return (
    <div>
      
    </div>
  )
}

export default admin
