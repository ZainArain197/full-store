import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from "react-redux";
import 'react-toastify/dist/ReactToastify.css';
import { toast } from 'react-toastify';
import { NavLink } from 'react-router-dom';
import { useParams } from 'react-router-dom';

const Details = () => {

    const getdata = useSelector((state) => state.Shoes);
    // console.log(getdata);

    const [data, setData] = useState([]);
    // console.log(data);

    const { id } = useParams();
    // console.log(id);
    // id mil rahi hai


    const compareId = () => {
        let compareData = getdata.filter((koiData) => {
            return koiData.id == id
        });
        setData(compareData);
        // console.log(compareData);
    }

    useEffect(() => {
        compareId();
    }, [id])

//------------------------------------------------------

    const dispatch = useDispatch();

    const send = (data) => {
        // console.log(Data);
        // carts.push(Data);
        // console.log(carts);
        toast("Product Added To Cart!");
        dispatch({
            type: "ADD_CART",
            payload: data
        })

    }


    return (
        <>
          <h2 className='text-center ' > Details of Selected Product</h2>
            {
                getdata.length ?
                    <div className="container mt-100">

                        {
                            data.map((data, id) => {

                                return (
                                    <>
                                        <div className="row">
                                            <div className="col-6">
                                                <div className="details__image">
                                                    <img src={data.imgdata} alt="" />
                                                </div>
                                            </div>
                                            <div className="col-6">
                                                <div className="details__name">
                                                    {data.name}
                                                </div>
                                                <div className="details__prices">

                                                    <strong>Price : </strong>      <span className="details__actaul">{data.price}</span>

                                                </div>
                                                <div className="details__info">
                                                    <strong>Quantity : </strong>  <span className="details__actaul">{data.qnty}</span>
                                                   
                                                    <NavLink id='link' to={`/cart/${data.id}`}  >
                                                        <div className="details__incDec " >
                                                            <button className="btn-default" 
                                                            onClick={() => send(data)}
                                                            >ADD TO CART</button>
                                                        </div>
                                                    </NavLink>
                                                </div>
                                                <div className="details__p">
                                                    <h4>Details</h4>
                                                    {data.Disription}
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                )
                            })
                        }

                    </div> :


                    <div className='card_details d-flex justify-content-center align-items-center' style={{ padding: "50px", position: "relative" }}>

                        <p style={{ fontSize: 22 }}><h1>No Product Selected!</h1></p>
                        <img src="./cart.gif" alt="" className='emptycart_img' style={{ width: "5rem", padding: 10 }} />
                    </div>

            }
        </>
    )
}

export default Details
