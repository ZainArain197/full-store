import React from 'react';
import "./checkout.css";
import { useForm } from 'react-hook-form';

const Checkout = () => {
    let data = useForm();
    const submitData = (userData) => {
        console.log(userData);
        // data a raha hai.
        data.reset();
    }

    return (
        <>
            <>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link
                    rel="stylesheet"
                    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
                />

                <div className="rowq">
                    <div className="col-75">
                        <div className="container">
                            <form onSubmit={data.handleSubmit(submitData)}>
                                <div className="rowq">
                                    <div className="col-50">
                                        <h3>Billing Address</h3>
                                        <label htmlFor="fname">
                                            <i className="fa fa-user" /> Full Name
                                        </label>
                                        <input
                                            type="text"
                                            id="fname"
                                            name="firstname"
                                            placeholder="Enter Your Name"
                                            {...data.register("firstname", { required: true })}
                                        />
                                        <label htmlFor="email">
                                            <i className="fa fa-envelope" /> Email
                                        </label>
                                        <input
                                            type="text"
                                            id="email"
                                            name="email"
                                            placeholder="Enter Your Email"
                                            {...data.register("email", { required: true })}
                                        />
                                        <label htmlFor="adr">
                                            <i className="fa fa-address-card-o" /> Address
                                        </label>
                                        <input
                                            type="text"
                                            id="adr"
                                            name="address"
                                            placeholder="Enter Your Address"
                                            {...data.register("address", { required: true })}
                                        />
                                        <label htmlFor="city">
                                            <i className="fa fa-institution" /> City
                                        </label>
                                        <input type="text" id="city" name="city" placeholder="Enter Your City"
                                            {...data.register("city", { required: true })}
                                        />
                                        <div className="row">
                                            <div className="col-50">
                                                <label htmlFor="state">State</label>
                                                <input type="text" id="state" name="state" placeholder="Enter Your State"
                                                    {...data.register("state", { required: true })}
                                                />
                                            </div>
                                            <div className="col-50">
                                                <label htmlFor="zip">Zip-Code</label>
                                                <input type="text" id="zip" name="zip" placeholder="Enter ZipCode"
                                                    {...data.register("zip", { required: true })}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-50">
                                        <h3>Payment</h3>
                                        <label htmlFor="fname">Accepted Cards</label>
                                        <div className="icon-container">
                                            <i className="fa fa-cc-visa" style={{ color: "navy" }} />
                                            <i className="fa fa-cc-amex" style={{ color: "blue" }} />
                                            <i className="fa fa-cc-mastercard" style={{ color: "red" }} />
                                            <i className="fa fa-cc-discover" style={{ color: "orange" }} />
                                        </div>
                                        <label htmlFor="cname">Name on Card</label>
                                        <input
                                            type="text"
                                            id="cname"
                                            name="cardname"
                                            placeholder="Enter Your Name"
                                            {...data.register("cardname", { required: true })}
                                        />
                                        <label htmlFor="ccnum">Credit / Debit Card Number</label>
                                        <input
                                            type="text"
                                            id="ccnum"
                                            name="cardnumber"
                                            placeholder="1111-2222-3333-4444"
                                            {...data.register("cardnumber", { required: true })}
                                        />
                                        <label htmlFor="expmonth">Exp Month</label>
                                        <input
                                            type="text"
                                            id="expmonth"
                                            name="expmonth"
                                            placeholder=" Expiring Month"
                                            {...data.register("expmonth", { required: true })}
                                        />
                                        <div className="row">
                                            <div className="col-50">
                                                <label htmlFor="expyear">Exp Year</label>
                                                <input
                                                    type="text"
                                                    id="expyear"
                                                    name="expyear"
                                                    placeholder="Expiring Year"
                                                    {...data.register("expyear", { required: true })}
                                                />
                                            </div>
                                            <div className="col-50">
                                                <label htmlFor="cvv">CVV</label>
                                                <input type="text" id="cvv" name="cvv" placeholder="CVV"
                                                    {...data.register("cvv", { required: true })}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <label>
                                    <input type="checkbox" defaultChecked="checked" name="sameadress"
                                     {...data.register("sameadress", { required: true })}
                                    />
                                    Shipping address same as billing
                                </label>
                                <input
                                    type="submit"
                                    defaultValue="Continue to checkout"
                                    className="btn"
                                />
                            </form>
                        </div>
                    </div>
                    <div className="col-25">
                        <div className="container">
                            <h4>
                                Cart
                                <span className="price" style={{ color: "black" }}>
                                    <i className="fa-solid fa-cart-shopping  " style={{ fontSize: 25, cursor: "pointer" }}></i> <b>4</b>
                                </span>
                            </h4>
                            <p>
                                <a >Product 1</a> <span className="price">$15</span>
                            </p>
                            <p>
                                <a >Product 2</a> <span className="price">$5</span>
                            </p>
                            <p>
                                <a >Product 3</a> <span className="price">$8</span>
                            </p>
                            <p>
                                <a >Product 4</a> <span className="price">$2</span>
                            </p>
                            <hr />
                            <p>
                                Total
                                <span className="price" style={{ color: "black" }}>
                                    <b>$30</b>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </>

        </>
    )
}

export default Checkout
