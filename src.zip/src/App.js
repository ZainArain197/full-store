import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CardsDetails from './components/CardsDetails';
import Cards from './components/Cards';
import meraStore from './Store/Store';
import { Provider } from 'react-redux';
import Home from './components/Home';
import Footer from './components/Footer';
import ContactUs from './components/ContactUs';
import { ToastContainer } from 'react-toastify';
import Details from './components/Details';
import Checkout from './components/CheckOut/Checkout';
import Signup from './components/signup/signup';
import Login from './components/Login/Login';




function App() {
  return (
    <>
      <Provider store={meraStore}>
        <BrowserRouter>

          <Header />

          <Routes>

            <Route path='/' element={<Home />} />
            <Route path='/Signup' element={<Signup />} />
            <Route path='/Login' element={<Login />} />
            <Route path='/contact' element={<ContactUs />} />
            <Route path='/Details/:id' element={<Details />} />
            <Route path='/Cards' element={<Cards />} />
            <Route path='/cart/:id' element={<CardsDetails />} />
            <Route path='/Checkout/' element={<Checkout />} />
          </Routes>
          <Footer />

          <ToastContainer></ToastContainer >
        </BrowserRouter>
      </Provider>
    </>
  );
}

export default App;